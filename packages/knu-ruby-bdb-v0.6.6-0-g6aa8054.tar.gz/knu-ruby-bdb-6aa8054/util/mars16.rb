require 'mkmf'
create_makefile('marshal16')
